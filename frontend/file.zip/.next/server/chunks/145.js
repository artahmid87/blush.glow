"use strict";
exports.id = 145;
exports.ids = [145];
exports.modules = {

/***/ 4482:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Container = ({ className , children  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: `${className} max-w-[1480px] mx-auto px-4`,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Container);


/***/ }),

/***/ 6145:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/components/ui/Container.jsx
var Container = __webpack_require__(4482);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./src/components/ui/icon.jsx
var icon = __webpack_require__(4068);
;// CONCATENATED MODULE: ./src/components/shared/navbar/ToggleBar.jsx



function ToggleBar() {
    const [isOpen, setIsOpen] = (0,external_react_.useState)(false);
    const toggleMenu = ()=>{
        setIsOpen(!isOpen);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `fixed invisible md:visible top-0 left-[-200px] h-full w-[40%] bg-white text-tertiary transition-transform transform ${isOpen ? "translate-x-[180px]" : "-translate-x-full"}`,
                style: {
                    zIndex: "9999"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                    className: "py-4 px-8",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/images/home/logo.png",
                                alt: ""
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-[16px] text-secondery py-4 text-center",
                                children: "We take a bottom-line approach to each project. Our clients consistently see increased traffic, enhanced brand loyalty and new leads thanks to our work."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " gap-20 w-full md:text-md lg:text-2xl ",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        className: "flex gap-2 ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "mt-1",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(icon.LocationIcon, {})
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: " https://www.google.com/maps/place/Blush+%26+Glow+Beauty+Bar/@43.6961831,-79.2929566,17z/data=!4m14!1m7!3m6!1s0x38d840a6f5aec37:0x1292455a177a54ce!2sBlush+%26+Glow+Beauty+Bar!8m2!3d43.6961831!4d-79.2929566!16s%2Fg%2F11s1sbcm3v!3m5!1s0x38d840a6f5aec37:0x1292455a177a54ce!8m2!3d43.6961831!4d-79.2929566!16s%2Fg%2F11s1sbcm3v?entry=ttu&g_ep=EgoyMDI0MTEwNi4wIKXMDSoASAFQAw%3D%3D",
                                                    children: "5 Massey Square, East York, ON M4C 5L6, canada."
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        className: "flex gap-2 py-6 ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "mt-1",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(icon.PhoneIcon, {})
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "cellto",
                                                children: "Call: +1 (647)-607-2276"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        className: "flex gap-2 ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "mt-1",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(icon.EmailIcon, {})
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "mailto:blushglowbar@gmail.com",
                                                children: "blushglowbar@gmail.com"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "flex gap-10 pt-10",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "text-3xl hover:text-primary transition-all",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "#",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(icon.FacebookIcon, {})
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "text-3xl hover:text-primary transition-all",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "#",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(icon.InstagramIcon, {})
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "text-4xl hover:text-primary transition-all",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "#",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(icon.YoutubeIcon, {})
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                onClick: toggleMenu,
                className: ` focus:outline-none text-2xl ${isOpen ? "text-white z-50 " : "text-tertiary"}`,
                type: "button",
                children: isOpen ? /*#__PURE__*/ jsx_runtime_.jsx(icon.CloseIcon, {}) : /*#__PURE__*/ jsx_runtime_.jsx(icon.OpenIcon, {})
            }),
            isOpen && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "fixed inset-0 bg-black opacity-50 z-40",
                onClick: toggleMenu
            })
        ]
    });
}

// EXTERNAL MODULE: external "gsap"
var external_gsap_ = __webpack_require__(4287);
;// CONCATENATED MODULE: ./src/components/shared/navbar/Navbar.jsx




 // Import useRouter



external_gsap_.gsap.config({
    nullTargetWarn: false,
    trialWarn: false
});
const Navbar = ()=>{
    const [isOpen, setIsOpen] = (0,external_react_.useState)(false);
    const navbarRef = (0,external_react_.useRef)(null);
    const mobileMenuRef = (0,external_react_.useRef)(null);
    const router = (0,router_.useRouter)();
    const toggleMenu = ()=>{
        setIsOpen((prev)=>!prev);
    };
    (0,external_react_.useEffect)(()=>{
        const handleScroll = ()=>{
            const scrollPosition = window.scrollY;
            if (scrollPosition > 50) {
                external_gsap_.gsap.to(navbarRef.current, {
                    backgroundColor: "#fff",
                    duration: 1,
                    boxShadow: "2px 2px 10px gray"
                });
                external_gsap_.gsap.to(".list", {
                    color: "#000",
                    duration: 1
                });
            } else {
                external_gsap_.gsap.to(navbarRef.current, {
                    backgroundColor: "transparent",
                    duration: 1,
                    boxShadow: "0px 0px 0px gray"
                });
                external_gsap_.gsap.to(".list", {
                    color: "#fff",
                    duration: 1
                });
            }
        };
        window.addEventListener("scroll", handleScroll);
        return ()=>{
            window.removeEventListener("scroll", handleScroll);
        };
    }, []);
    (0,external_react_.useEffect)(()=>{
        if (isOpen) {
            external_gsap_.gsap.fromTo(mobileMenuRef.current, {
                opacity: 0,
                y: -20
            }, {
                opacity: 1,
                y: 0,
                duration: 0.5
            });
        } else {
            external_gsap_.gsap.to(mobileMenuRef.current, {
                opacity: 0,
                y: -20,
                duration: 0.5,
                onComplete: ()=>{
                    external_gsap_.gsap.set(mobileMenuRef.current, {
                        clearProps: "all"
                    });
                }
            });
        }
    }, [
        isOpen
    ]);
    const isActiveLink = (path)=>router.pathname === path;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        style: {
            zIndex: 999
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
            ref: navbarRef,
            className: "bg-transparent text font-secondery w-full md:p-4 fixed top-0 left-0",
            style: {
                zIndex: 999
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Container/* default */.Z, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "container mx-auto flex justify-between items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: "invisible md:visible w-[200px] md:w-[250px] md:-ml-10 lg:-ml-0 h-14",
                                        src: "/images/home/logo.png",
                                        alt: "Logo"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "hidden md:flex mr-10 space-x-4 text-xl",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: ` hover:text-primary transition-all p-2 rounded ${isActiveLink("/") ? "text-primary" : "text-tertiary"}`,
                                        href: "/",
                                        children: "Home"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: ` hover:text-primary transition-all p-2 rounded ${isActiveLink("/services") ? "text-primary" : "text-tertiary"}`,
                                        href: "/services",
                                        children: "Services"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: ` hover:text-primary transition-all p-2 rounded ${isActiveLink("/appointment") ? "text-primary" : "text-tertiary"}`,
                                        href: "/appointment",
                                        children: "Appointment"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: ` hover:text-primary transition-all p-2 rounded ${isActiveLink("/contact") ? "text-primary" : "text-tertiary"}`,
                                        href: "/contact",
                                        children: "Contact"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ToggleBar, {})
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "md:hidden w-full h-6 flex justify-between",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "w-[200px] h-6 -ml-28",
                                        href: "/",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            className: "visible md:invisible",
                                            src: "/images/home/logo.png",
                                            alt: "Logo"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        onClick: toggleMenu,
                                        className: "text-white bg-primary w-8 h-8 focus:outline-none text-2xl flex justify-center items-center",
                                        type: "button",
                                        children: isOpen ? /*#__PURE__*/ jsx_runtime_.jsx(icon.CloseIcon, {}) : /*#__PURE__*/ jsx_runtime_.jsx(icon.OpenIcon, {})
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        ref: mobileMenuRef,
                        className: `md:hidden bg-white p-4 w-[140%] py-20 -ml-20 -mt-32 h-[120dvh] ${isOpen ? "block" : "hidden"}`,
                        style: {
                            zIndex: "9999"
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "space-y-2 w-full flex flex-col justify-center items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: "w-[200px] md:hidden md:w-[250px] h-14",
                                        src: "/images/home/logo.png",
                                        alt: "Logo"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        onClick: toggleMenu,
                                        className: `block text-tertiary hover:text-primary transition-all p-2 rounded ${isActiveLink("/") ? "text-primary" : ""}`,
                                        href: "/",
                                        children: "Home"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        onClick: toggleMenu,
                                        className: `block text-tertiary hover:text-primary transition-all p-2 rounded ${isActiveLink("/services") ? "text-primary" : ""}`,
                                        href: "/services",
                                        children: "Services"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        onClick: toggleMenu,
                                        className: `block text-tertiary hover:text-primary transition-all p-2 rounded ${isActiveLink("/contact") ? "text-primary" : ""}`,
                                        href: "/contact",
                                        children: "Contact"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mt-4 flex flex-col justify-end items-center text-center text-sm w-1/2 ml-28",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "flex gap-2 text-sm",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: " https://www.google.com/maps/place/Blush+%26+Glow+Beauty+Bar/@43.6961831,-79.2929566,17z/data=!4m14!1m7!3m6!1s0x38d840a6f5aec37:0x1292455a177a54ce!2sBlush+%26+Glow+Beauty+Bar!8m2!3d43.6961831!4d-79.2929566!16s%2Fg%2F11s1sbcm3v!3m5!1s0x38d840a6f5aec37:0x1292455a177a54ce!8m2!3d43.6961831!4d-79.2929566!16s%2Fg%2F11s1sbcm3v?entry=ttu&g_ep=EgoyMDI0MTEwNi4wIKXMDSoASAFQAw%3D%3D",
                                                children: "5 Massey Square, East York, ON M4C 5L6, canada."
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "flex gap-2 -ml-4 py-6 ",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "cellto",
                                            children: "Call: +1 (647)-607-2276"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "flex gap-2 ",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "mailto:blushglowbar@gmail.com",
                                            children: "blushglowbar@gmail.com"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "flex gap-10 pt-10",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "text-3xl hover:text-primary transition-all",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "#",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(icon.FacebookIcon, {})
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "text-3xl hover:text-primary transition-all",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "#",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(icon.InstagramIcon, {})
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "text-4xl hover:text-primary transition-all",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "#",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(icon.YoutubeIcon, {})
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const navbar_Navbar = (Navbar);

;// CONCATENATED MODULE: ./src/components/shared/footer/mainFooter.jsx





function MainFooter() {
    const { pathname  } = (0,router_.useRouter)();
    const path = "/";
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: `${pathname !== path ? "bg-[#252525] text-white" : "bg-[#ffffff] text-tertiary"}   py-14 relative`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Container/* default */.Z, {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 px-6 lg:h-[60vh]",
                    style: {
                        zIndex: 999
                    },
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: `${pathname !== path ? "text-white" : " text-tertiary"} text-lg md:text-4xl font-semibold mb-8 font-secondery`,
                                    children: "About Us"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-sm md:text-lg ",
                                    children: "Blush & Glow Beauty Bar is your go-to destination for luxurious beauty services. Our team of professionals is dedicated to enhancing your natural beauty with personalized care."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/appointment",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                        className: "group hover:bg-primary bg-white transition-all py-2 mt-10 px-8 flex gap-2 justify-center items-center rounded-full",
                                        style: {
                                            boxShadow: "1px 1px 8px gray"
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "flex justify-center items-center text-2xl group-hover:text-primary text-white transition-all w-8 h-8 md:w-10 md:h-10 group-hover:bg-white bg-primary rounded-full ml-[-20px]",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(icon.CalenderIcon, {})
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "text-md md:text-lg transition-all group-hover:text-white text-primary font-secondery",
                                                children: "Make An Appointment"
                                            })
                                        ]
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: `${pathname !== path ? "text-white" : " text-tertiary"}text-lg md:text-4xl font-semibold mb-8 font-secondery`,
                                    children: "Quick Links"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "space-y-6 text-sm md:text-xl",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                className: "hover:underline",
                                                href: "/about",
                                                children: " About "
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                className: "hover:underline",
                                                href: "/imageShowcase",
                                                children: " Gallery "
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                className: "hover:underline",
                                                href: "/blog",
                                                children: "Blog"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                className: "hover:underline",
                                                href: "/faq",
                                                children: "FAQs "
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                className: "hover:underline",
                                                href: "/privacy-policy",
                                                children: "Privacy Policy "
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                className: "hover:underline",
                                                href: "/terms-conditions",
                                                children: "Terms & Conditions"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: " gap-20 w-full",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: `${pathname !== path ? "text-white" : " text-tertiary"}text-lg md:text-4xl font-semibold mb-8 font-secondery`,
                                    children: "Contact us"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: "flex gap-2 text-sm md:text-xl",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "mt-1",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(icon.LocationIcon, {})
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: " https://www.google.com/maps/place/Blush+%26+Glow+Beauty+Bar/@43.6961831,-79.2929566,17z/data=!4m14!1m7!3m6!1s0x38d840a6f5aec37:0x1292455a177a54ce!2sBlush+%26+Glow+Beauty+Bar!8m2!3d43.6961831!4d-79.2929566!16s%2Fg%2F11s1sbcm3v!3m5!1s0x38d840a6f5aec37:0x1292455a177a54ce!8m2!3d43.6961831!4d-79.2929566!16s%2Fg%2F11s1sbcm3v?entry=ttu&g_ep=EgoyMDI0MTEwNi4wIKXMDSoASAFQAw%3D%3D",
                                                children: "5 Massey Square, East York, ON M4C 5L6, canada."
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: "flex gap-2 py-6 text-sm md:text-xl",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "mt-1",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(icon.PhoneIcon, {})
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "cellto",
                                            children: "Call: +1 (647)-607-2276"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: "flex gap-2 text-sm md:text-xl",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "mt-1",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(icon.EmailIcon, {})
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "mailto:blushglowbar@gmail.com",
                                            children: "blushglowbar@gmail.com"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "flex gap-10 pt-10",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "text-3xl hover:text-primary transition-all",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(icon.FacebookIcon, {})
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "text-3xl hover:text-primary transition-all",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(icon.InstagramIcon, {})
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "text-4xl hover:text-primary transition-all",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(icon.YoutubeIcon, {})
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full ",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("iframe", {
                                src: "https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d721.1727982288214!2d-79.292957!3d43.696183!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38d840a6f5aec37%3A0x1292455a177a54ce!2sBlush%20%26%20Glow%20Beauty%20Bar!5e0!3m2!1sen!2sbd!4v1720508571658!5m2!1sen!2sbd",
                                className: "w-full h-full",
                                allowFullScreen: "",
                                loading: "lazy",
                                referrerPolicy: "no-referrer-when-downgrade"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "invisible md:visible banner animate-slide-left-right absolute -top-20 left-0 -ml-20 py-6",
                style: {
                    zIndex: 0
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: "/images/home/footer.png",
                    alt: ""
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mt-8 border-t border-gray-700 pt-4 text-center text-md",
                children: [
                    "\xa9 ",
                    new Date().getFullYear(),
                    " Blush & Glow Beauty Bar. All rights reserved."
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/components/shared/footer/Footer.jsx



const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "overflow-hidden",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            children: /*#__PURE__*/ jsx_runtime_.jsx(MainFooter, {})
        })
    });
};
/* harmony default export */ const footer_Footer = (Footer);

;// CONCATENATED MODULE: ./src/layouts/MainLayout.jsx




const MainLayout = ({ children  })=>{
    const { pathname  } = (0,router_.useRouter)();
    const hiddenRoutes = [
        "/login",
        "/dashboard",
        "/dashboard/bookingList",
        "/dashboard/blog",
        "/dashboard/newPost",
        "/dashboard/updateBlog",
        "/dashboard/uploadGallery",
        "/dashboard/gallery",
        "/dashboard/displayServices",
        "/dashboard/category",
        "/dashboard/addPrice",
        "/dashboard/updateBlog/[id]",
        "/dashboard/gallery/[id]",
        "/dashboard/confirmationBooking/[id]",
        "/dashboard/updateCategory/[id]",
        "/dashboard/updatePrice/[id]",
        "/dashboard/blog-category"
    ];
    const showNavbarFooter = !hiddenRoutes.includes(pathname);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            showNavbarFooter && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "size-5 fixed hidden lg:block left-0 top-0 bg-blue rounded-full",
                        style: {
                            zIndex: 99999
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(navbar_Navbar, {})
                ]
            }),
            children,
            showNavbarFooter && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(footer_Footer, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "fixed bottom-8 right-8 border-[4.5px] bg-white text-blue rounded-full cursor-pointer transition-all flex justify-center items-center size-14 lg:size-20 duration-300",
                        style: {
                            zIndex: 999
                        }
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const layouts_MainLayout = (MainLayout);

;// CONCATENATED MODULE: ./src/pages/_layout.jsx



const Layout = ({ children  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        children: /*#__PURE__*/ jsx_runtime_.jsx(layouts_MainLayout, {
            children: children
        })
    });
};
/* harmony default export */ const _layout = (Layout);


/***/ })

};
;