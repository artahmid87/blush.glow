"use strict";
exports.id = 298;
exports.ids = [298];
exports.modules = {

/***/ 8298:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var swiper_modules__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2184);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3015);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7644);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ui_Container__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4482);
/* harmony import */ var _redux_api_Api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6627);
/* harmony import */ var _ui_reusableComponent_HeadingComponent__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8002);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_modules__WEBPACK_IMPORTED_MODULE_1__, swiper_react__WEBPACK_IMPORTED_MODULE_2__, _redux_api_Api__WEBPACK_IMPORTED_MODULE_5__]);
([swiper_modules__WEBPACK_IMPORTED_MODULE_1__, swiper_react__WEBPACK_IMPORTED_MODULE_2__, _redux_api_Api__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



// Import Swiper styles




const Review = ()=>{
    // query
    const { data , isSuccess , isLoading , isError  } = (0,_redux_api_Api__WEBPACK_IMPORTED_MODULE_5__/* .useReviewQuery */ .$B)();
    // This is Headline Data pass with HaedingComponent as for create Reusable component 
    // Component path  "../ui/reusableComponent/HeadingComponent"
    const headingData = [
        {
            headline: "Review",
            title1: "Client",
            title2: "Feedback",
            description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo  maecenas accumsan lacus vel facilisis.`
        }
    ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "py-20",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_reusableComponent_HeadingComponent__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                headingData: headingData
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.Swiper, {
                slidesPerView: 1,
                autoplay: {
                    delay: 4000
                },
                loop: true,
                speed: 1200,
                pagination: {
                    clickable: true
                },
                navigation: true,
                modules: [
                    swiper_modules__WEBPACK_IMPORTED_MODULE_1__.Autoplay,
                    swiper_modules__WEBPACK_IMPORTED_MODULE_1__.Pagination,
                    swiper_modules__WEBPACK_IMPORTED_MODULE_1__.Navigation
                ],
                children: data?.review?.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.SwiperSlide, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            href: item.reviewLink,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "relative py-20 bg-cover bg-top md:bg-none overflow-hidden",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_Container__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex justify-center items-center",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "md:w-[80%] w-full flex flex-col justify-center items-center",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                    className: "text-center text-tertiary text-xl md:text-3xl font-secondery italic",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "text-4xl",
                                                            children: "“"
                                                        }),
                                                        item.description,
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "text-4xl",
                                                            children: "”"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                    className: "text-xl mt-10 font-semibold text-primary",
                                                    children: item.name
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    className: "w-20 h-10",
                                                    src: "images/home/star.png",
                                                    alt: ""
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    className: "w-[60px] h-[60px] rounded-full border-2 border-gray-400 mt-4",
                                                    src: item.imageUrl,
                                                    alt: ""
                                                })
                                            ]
                                        })
                                    })
                                })
                            })
                        })
                    }, item.id))
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Review);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;