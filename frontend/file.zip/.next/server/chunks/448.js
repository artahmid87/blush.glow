"use strict";
exports.id = 448;
exports.ids = [448];
exports.modules = {

/***/ 448:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ dashboardLayout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/components/ui/icon.jsx
var icon = __webpack_require__(4068);
;// CONCATENATED MODULE: ./src/components/Dashboard/sidebar.jsx



 // Assuming you have a dropdown icon
const Sidebar = ()=>{
    const [isOpen, setIsOpen] = (0,external_react_.useState)(false);
    const [activeMenu, setActiveMenu] = (0,external_react_.useState)(null); // Tracks active dropdown menu
    const toggleMenu = (menu)=>{
        setActiveMenu(activeMenu === menu ? null : menu);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
        className: "bg-gray-800 text-white p-6",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "hidden lg:flex flex-col items-center w-60",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-2xl font-bold mb-8",
                        children: "Dashboard"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/",
                                    children: "Home"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "py-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/dashboard",
                                    children: "Appointment"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-4",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: `flex items-center cursor-pointer ${activeMenu === "blog" ? "text-blue-500" : ""}`,
                                        onClick: ()=>toggleMenu("blog"),
                                        children: [
                                            "Blog",
                                            /*#__PURE__*/ jsx_runtime_.jsx(icon.DropdownIcon, {
                                                size: 18,
                                                className: "ml-2"
                                            })
                                        ]
                                    }),
                                    activeMenu === "blog" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "ml-6 space-y-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/dashboard/blog",
                                                    children: "Blog List"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/dashboard/newPost",
                                                    children: "Create Post"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/dashboard/blog-category",
                                                    children: "Blog Category"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-4",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: `flex items-center cursor-pointer ${activeMenu === "gallery" ? "text-blue-500" : ""}`,
                                        onClick: ()=>toggleMenu("gallery"),
                                        children: [
                                            "Gallery",
                                            /*#__PURE__*/ jsx_runtime_.jsx(icon.DropdownIcon, {
                                                size: 18,
                                                className: "ml-2"
                                            })
                                        ]
                                    }),
                                    activeMenu === "gallery" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "ml-6 space-y-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/dashboard/gallery",
                                                    children: "Gallery List"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/dashboard/uploadGallery",
                                                    children: "Post Gallery"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-4",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: `flex items-center cursor-pointer ${activeMenu === "services" ? "text-blue-500" : ""}`,
                                        onClick: ()=>toggleMenu("services"),
                                        children: [
                                            "Services",
                                            /*#__PURE__*/ jsx_runtime_.jsx(icon.DropdownIcon, {
                                                size: 18,
                                                className: "ml-2"
                                            })
                                        ]
                                    }),
                                    activeMenu === "services" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "ml-6 space-y-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/dashboard/displayServices",
                                                    children: "Service List"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/dashboard/addPrice",
                                                    children: "Add Service"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/dashboard/category",
                                                    children: "Category"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "hidden md:flex lg:hidden flex-col items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex justify-between items-center w-full",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-2xl font-bold",
                                children: "Dashboard"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                onClick: ()=>setIsOpen(!isOpen),
                                "aria-label": "Toggle Sidebar",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(icon.OpenIcon, {
                                    size: 24
                                })
                            })
                        ]
                    }),
                    isOpen && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "mt-4 space-y-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "py-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/",
                                    children: "Home"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "py-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/dashboard",
                                    children: "Appointment"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: `flex items-center cursor-pointer ${activeMenu === "blog" ? "text-blue-500" : ""}`,
                                        onClick: ()=>toggleMenu("blog"),
                                        children: [
                                            "Blog",
                                            /*#__PURE__*/ jsx_runtime_.jsx(icon.DropdownIcon, {
                                                size: 18,
                                                className: "ml-2"
                                            })
                                        ]
                                    }),
                                    activeMenu === "blog" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "ml-6 space-y-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/dashboard/blog",
                                                    children: "Blog List"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/dashboard/newPost",
                                                    children: "Create Post"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/dashboard/blog-category",
                                                    children: "Blog Category"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: `flex items-center cursor-pointer ${activeMenu === "gallery" ? "text-blue-500" : ""}`,
                                        onClick: ()=>toggleMenu("gallery"),
                                        children: [
                                            "Gallery",
                                            /*#__PURE__*/ jsx_runtime_.jsx(icon.DropdownIcon, {
                                                size: 18,
                                                className: "ml-2"
                                            })
                                        ]
                                    }),
                                    activeMenu === "gallery" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "ml-6 space-y-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/dashboard/gallery",
                                                    children: "Gallery List"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/dashboard/uploadGallery",
                                                    children: "Post Gallery"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: `flex items-center cursor-pointer ${activeMenu === "services" ? "text-blue-500" : ""}`,
                                        onClick: ()=>toggleMenu("services"),
                                        children: [
                                            "Services",
                                            /*#__PURE__*/ jsx_runtime_.jsx(icon.DropdownIcon, {
                                                size: 18,
                                                className: "ml-2"
                                            })
                                        ]
                                    }),
                                    activeMenu === "services" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "ml-6 space-y-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/dashboard/displayServices",
                                                    children: "Service List"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/dashboard/addPrice",
                                                    children: "Add Service"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/dashboard/category",
                                                    children: "Category"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "md:hidden flex justify-between items-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-2xl font-bold",
                        children: "Dashboard"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>setIsOpen(!isOpen),
                        "aria-label": "Toggle Sidebar",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(icon.OpenIcon, {
                            size: 24
                        })
                    })
                ]
            }),
            isOpen && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "flex flex-col items-center mt-4 space-y-4 md:hidden",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "py-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/",
                                    children: "Home"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "py-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/dashboard",
                                    children: "Appointment"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: `flex items-center cursor-pointer ${activeMenu === "blog" ? "text-blue-500" : ""}`,
                                onClick: ()=>toggleMenu("blog"),
                                children: [
                                    "Blog",
                                    /*#__PURE__*/ jsx_runtime_.jsx(icon.DropdownIcon, {
                                        size: 18,
                                        className: "ml-2"
                                    })
                                ]
                            }),
                            activeMenu === "blog" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "ml-6 space-y-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/dashboard/blog",
                                            children: "Blog List"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/dashboard/newPost",
                                            children: "Create Post"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/dashboard/blog-category",
                                            children: "Blog Category"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: `flex items-center cursor-pointer ${activeMenu === "gallery" ? "text-blue-500" : ""}`,
                                onClick: ()=>toggleMenu("gallery"),
                                children: [
                                    "Gallery",
                                    /*#__PURE__*/ jsx_runtime_.jsx(icon.DropdownIcon, {
                                        size: 18,
                                        className: "ml-2"
                                    })
                                ]
                            }),
                            activeMenu === "gallery" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "ml-6 space-y-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/dashboard/gallery",
                                            children: "Gallery List"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/dashboard/uploadGallery",
                                            children: "Post Gallery"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: `flex items-center cursor-pointer ${activeMenu === "services" ? "text-blue-500" : ""}`,
                                onClick: ()=>toggleMenu("services"),
                                children: [
                                    "Services",
                                    /*#__PURE__*/ jsx_runtime_.jsx(icon.DropdownIcon, {
                                        size: 18,
                                        className: "ml-2"
                                    })
                                ]
                            }),
                            activeMenu === "services" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "ml-6 space-y-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/dashboard/displayServices",
                                            children: "Service List"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/dashboard/addPrice",
                                            children: "Add Service"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/dashboard/category",
                                            children: "Category"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const sidebar = (Sidebar);

;// CONCATENATED MODULE: ./src/layouts/dashboardLayout.jsx


const DashboardLayout = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col lg:flex-row",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(sidebar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: "flex-grow p-8 w-full",
                children: children
            })
        ]
    });
};
/* harmony default export */ const dashboardLayout = (DashboardLayout);


/***/ })

};
;