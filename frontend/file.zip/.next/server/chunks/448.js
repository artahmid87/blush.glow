"use strict";
exports.id = 448;
exports.ids = [448];
exports.modules = {

/***/ 448:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ dashboardLayout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/components/ui/icon.jsx
var icon = __webpack_require__(4068);
;// CONCATENATED MODULE: ./src/components/Dashboard/sidebar.jsx




const Sidebar = ()=>{
    const [isOpen, setIsOpen] = (0,external_react_.useState)(false);
    const [activeMenu, setActiveMenu] = (0,external_react_.useState)(null);
    const toggleMenu = (menu)=>{
        setActiveMenu(activeMenu === menu ? null : menu);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("nav", {
        className: " lg:h-[100dvh] bg-white border-r border-gray-400 text-secondery p-6",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col items-center lg:w-60",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "py-10",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "/images/home/logo.png",
                        alt: "Logo"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "hidden lg:flex flex-col w-full",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "text-secondery",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                className: "flex items-center",
                                href: "/dashboard",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(icon.DashboardIcon, {
                                        className: "text-2xl mr-2"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-2xl",
                                        children: "Dashboard"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "py-4 text-secondery",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                className: "flex items-center",
                                href: "/dashboard/appointment",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(icon.AppointmentIcon, {
                                        className: "text-2xl mr-2"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-2xl",
                                        children: "Appointment"
                                    })
                                ]
                            })
                        }),
                        renderDropdownMenu("blog", "Blog", icon.BlogIcon, [
                            {
                                name: "List of Blog",
                                href: "/dashboard/blog"
                            },
                            {
                                name: "Create Blog Post ",
                                href: "/dashboard/newPost"
                            },
                            {
                                name: "Blog\xa0Category",
                                href: "/dashboard/blog-category"
                            }
                        ]),
                        renderDropdownMenu("gallery", "Gallery", icon.GalleryIcon, [
                            {
                                name: "Gallery List",
                                href: "/dashboard/gallery"
                            },
                            {
                                name: "Post Gallery",
                                href: "/dashboard/uploadGallery"
                            }
                        ]),
                        renderDropdownMenu("services", "Services", icon.MakeUpIcon, [
                            {
                                name: "Service List",
                                href: "/dashboard/displayServices"
                            },
                            {
                                name: "Add Service",
                                href: "/dashboard/addPrice"
                            },
                            {
                                name: "Category",
                                href: "/dashboard/category"
                            }
                        ])
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex lg:hidden w-full flex-col",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex justify-between items-center w-full mb-4",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "text-2xl font-bold",
                                    children: "Dashboard"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    onClick: ()=>setIsOpen(!isOpen),
                                    "aria-label": "Toggle Sidebar",
                                    className: "text-3xl",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(icon.OpenIcon, {
                                        size: 24
                                    })
                                })
                            ]
                        }),
                        isOpen && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "space-y-4",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        className: "flex items-center text-2xl",
                                        href: "/dashboard",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(icon.DashboardIcon, {
                                                className: "text-xl mr-2"
                                            }),
                                            "Dashboard"
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        className: "flex items-center text-2xl",
                                        href: "/dashboard/appointment",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(icon.AppointmentIcon, {
                                                className: "text-2xl mr-2"
                                            }),
                                            "Appointment"
                                        ]
                                    })
                                }),
                                renderDropdownMenu("blog", "Blog", icon.BlogIcon, [
                                    {
                                        name: "List of Blog",
                                        href: "/dashboard/blog"
                                    },
                                    {
                                        name: "Create Blog Post",
                                        href: "/dashboard/newPost"
                                    },
                                    {
                                        name: "Blog\xa0Category",
                                        href: "/dashboard/blog-category"
                                    }
                                ]),
                                renderDropdownMenu("gallery", "Gallery", icon.GalleryIcon, [
                                    {
                                        name: "Gallery List",
                                        href: "/dashboard/gallery"
                                    },
                                    {
                                        name: "Post Gallery",
                                        href: "/dashboard/uploadGallery"
                                    }
                                ]),
                                renderDropdownMenu("services", "Services", icon.MakeUpIcon, [
                                    {
                                        name: "Service List",
                                        href: "/dashboard/displayServices"
                                    },
                                    {
                                        name: "Add Service",
                                        href: "/dashboard/addPrice"
                                    },
                                    {
                                        name: "Category",
                                        href: "/dashboard/category"
                                    }
                                ])
                            ]
                        })
                    ]
                })
            ]
        })
    });
    function renderDropdownMenu(key, label, Icon, links) {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
            className: "mb-4",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: `flex items-center cursor-pointer ${activeMenu === key ? "text-blue-500" : ""}`,
                    onClick: ()=>toggleMenu(key),
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                            className: "text-2xl mr-2"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "text-2xl",
                            children: label
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(icon.DropdownIcon, {
                            size: 18,
                            className: "ml-2"
                        })
                    ]
                }),
                activeMenu === key && /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    className: "ml-6 space-y-2 text-lg font-semibold text-gray-500",
                    children: links.map((link, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: link.href,
                                children: link.name
                            })
                        }, index))
                })
            ]
        });
    }
};
/* harmony default export */ const sidebar = (Sidebar);

;// CONCATENATED MODULE: ./src/layouts/dashboardLayout.jsx


const DashboardLayout = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col lg:flex-row",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(sidebar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: "flex-grow p-8 w-full",
                children: children
            })
        ]
    });
};
/* harmony default export */ const dashboardLayout = (DashboardLayout);


/***/ })

};
;