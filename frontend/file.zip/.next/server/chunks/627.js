"use strict";
exports.id = 627;
exports.ids = [627];
exports.modules = {

/***/ 6627:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$B": () => (/* binding */ useReviewQuery),
/* harmony export */   "Df": () => (/* binding */ useUpdatePricesMutation),
/* harmony export */   "Go": () => (/* binding */ useFindAllBlogCategoriesQuery),
/* harmony export */   "IZ": () => (/* binding */ useFindAllPriceQuery),
/* harmony export */   "KX": () => (/* binding */ useDeleteBlogMutation),
/* harmony export */   "Ls": () => (/* binding */ useDeletePriceMutation),
/* harmony export */   "NL": () => (/* binding */ useGetGalleryByIdQuery),
/* harmony export */   "OF": () => (/* binding */ useUploadGalleryMutation),
/* harmony export */   "T2": () => (/* binding */ useGetBookingByIdQuery),
/* harmony export */   "V0": () => (/* binding */ Api),
/* harmony export */   "VF": () => (/* binding */ useCreateBlogCategoryMutation),
/* harmony export */   "XM": () => (/* binding */ useDeleteBookingMutation),
/* harmony export */   "YP": () => (/* binding */ useUpdateBookingMutation),
/* harmony export */   "_m": () => (/* binding */ useGetPriceByIdQuery),
/* harmony export */   "cI": () => (/* binding */ useDeleteBlogCategoryMutation),
/* harmony export */   "hj": () => (/* binding */ useFindAllCategoriesQuery),
/* harmony export */   "i9": () => (/* binding */ useCreateBookingMutation),
/* harmony export */   "kS": () => (/* binding */ useGetCategoryByIdQuery),
/* harmony export */   "l2": () => (/* binding */ useDeleteGalleryMutation),
/* harmony export */   "l8": () => (/* binding */ useDeleteCategoryMutation),
/* harmony export */   "m7": () => (/* binding */ useCreateCategoryMutation),
/* harmony export */   "r0": () => (/* binding */ useCreatePriceMutation),
/* harmony export */   "rE": () => (/* binding */ useGetBlogByIdQuery),
/* harmony export */   "rN": () => (/* binding */ useBookingListQuery),
/* harmony export */   "sY": () => (/* binding */ useGetBlogQuery),
/* harmony export */   "sk": () => (/* binding */ useUpdateGalleryMutation),
/* harmony export */   "tI": () => (/* binding */ useAdminLoginMutation),
/* harmony export */   "yj": () => (/* binding */ useGetAllGalleryQuery)
/* harmony export */ });
/* unused harmony exports useBlogPostMutation, useUpdateBlogMutation, useGetBlogCategoryByIdQuery */
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9943);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__]);
_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const Api = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "postApi",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: "https://blush.glow.api.ara-dreamhome.com/"
    }),
    endpoints: (builder)=>({
            // Appointment booking api
            bookingList: builder.query({
                query: ()=>"/appointment/get/customer"
            }),
            getBookingById: builder.query({
                query: (id)=>`/appointment/get/${id}`
            }),
            // Update booking with sending a confirmation email
            updateBooking: builder.mutation({
                query: ({ id , booking  })=>({
                        url: `/appointment/confirmBooking/${id}`,
                        method: "PUT",
                        body: booking
                    })
            }),
            // review get api
            review: builder.query({
                query: ()=>"/review"
            }),
            // All Blog
            getBlog: builder.query({
                query: ()=>"/getBlog"
            }),
            // single blog by id
            getBlogById: builder.query({
                query: (id)=>`/getById/${id}`
            }),
            //Booking post api
            createBooking: builder.mutation({
                query: (booking)=>({
                        url: "/appointment/booking",
                        method: "POST",
                        body: booking
                    })
            }),
            //Blog post api
            blogPost: builder.mutation({
                query: (post)=>({
                        url: "/uploadBlog",
                        method: "POST",
                        body: post
                    })
            }),
            //Blog Category post api
            createBlogCategory: builder.mutation({
                query: (category)=>({
                        url: "/createBlogCategory",
                        method: "POST",
                        body: category
                    })
            }),
            //Blog  get category api
            findAllBlogCategories: builder.query({
                query: ()=>"/findBlogCategories"
            }),
            //Blog category get By ID api
            getBlogCategoryById: builder.query({
                query: (id)=>`/findBlogCategory/${id}`
            }),
            //Blog Category delete api
            deleteBlogCategory: builder.mutation({
                query: (id)=>({
                        url: `/deleteBlogCategory/${id}`,
                        method: "DELETE"
                    })
            }),
            //Category post api
            createCategory: builder.mutation({
                query: (category)=>({
                        url: "/createCategory",
                        method: "POST",
                        body: category
                    })
            }),
            //  get category api
            findAllCategories: builder.query({
                query: ()=>"/findCategories"
            }),
            // category get By ID api
            getCategoryById: builder.query({
                query: (id)=>`/findCategory/${id}`
            }),
            //Category delete api
            deleteCategory: builder.mutation({
                query: (id)=>({
                        url: `/deleteCategory/${id}`,
                        method: "DELETE"
                    })
            }),
            //Price post api
            createPrice: builder.mutation({
                query: (pricePlan)=>({
                        url: "/createPrice",
                        method: "POST",
                        body: pricePlan
                    })
            }),
            //  get category api
            findAllPrice: builder.query({
                query: ()=>"/findPrices"
            }),
            //Category Update api
            updatePrices: builder.mutation({
                query: ({ id , pricePut  })=>({
                        url: `/updatePrices/${id}`,
                        method: "PUT",
                        body: pricePut
                    })
            }),
            // gallery get By ID api
            getPriceById: builder.query({
                query: (id)=>`/findPrices/${id}`
            }),
            //Price delete api
            deletePrice: builder.mutation({
                query: (id)=>({
                        url: `/deletePrice/${id}`,
                        method: "DELETE"
                    })
            }),
            //Blog Update api
            updateBlog: builder.mutation({
                query: (id, update)=>({
                        url: `/updateBlog/${id}`,
                        method: "PUT",
                        body: update
                    })
            }),
            //Blog delete api
            deleteBlog: builder.mutation({
                query: (id)=>({
                        url: `/deleteBlog/${id}`,
                        method: "DELETE"
                    })
            }),
            //booking delete api
            deleteBooking: builder.mutation({
                query: (id)=>({
                        url: `/appointment/delete/booking/${id}`,
                        method: "DELETE"
                    })
            }),
            //admin login api
            adminLogin: builder.mutation({
                query: (credentials)=>({
                        url: "/admin/login",
                        method: "POST",
                        body: credentials
                    })
            }),
            //Gallery post api
            uploadGallery: builder.mutation({
                query: (gallery)=>({
                        url: "/galleryUpload",
                        method: "POST",
                        body: gallery
                    })
            }),
            // gallery get api
            getAllGallery: builder.query({
                query: ()=>"/getGallery"
            }),
            // gallery get By ID api
            getGalleryById: builder.query({
                query: (id)=>`/getGelleryById/${id}`
            }),
            //Gallery Update api
            updateGallery: builder.mutation({
                query: ({ id , update  })=>({
                        url: `/updateGallery/${id}`,
                        method: "PUT",
                        body: update
                    })
            }),
            //Gallery delete api
            deleteGallery: builder.mutation({
                query: (id)=>({
                        url: `/deleteGallery/${id}`,
                        method: "DELETE"
                    })
            })
        })
});
const { useBookingListQuery , useAdminLoginMutation , useDeleteBookingMutation , useCreateBookingMutation , useReviewQuery , useGetBlogByIdQuery , useGetBlogQuery , useBlogPostMutation , useDeleteBlogMutation , useUpdateBlogMutation , useUploadGalleryMutation , useGetAllGalleryQuery , useUpdateGalleryMutation , useGetGalleryByIdQuery , useDeleteGalleryMutation , useGetBookingByIdQuery , useUpdateBookingMutation , useCreateCategoryMutation , useDeleteCategoryMutation , useFindAllCategoriesQuery , useGetCategoryByIdQuery , useCreatePriceMutation , useFindAllPriceQuery , useUpdatePricesMutation , useGetPriceByIdQuery , useDeletePriceMutation , useCreateBlogCategoryMutation , useDeleteBlogCategoryMutation , useFindAllBlogCategoriesQuery , useGetBlogCategoryByIdQuery  } = Api;

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;