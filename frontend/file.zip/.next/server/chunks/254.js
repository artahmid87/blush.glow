"use strict";
exports.id = 254;
exports.ids = [254];
exports.modules = {

/***/ 7254:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ui_Container__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4482);
/* harmony import */ var _form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4464);
/* harmony import */ var _Schedule__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4356);
/* harmony import */ var gsap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4287);
/* harmony import */ var gsap__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(gsap__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var gsap_dist_ScrollTrigger__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4965);
/* harmony import */ var gsap_dist_ScrollTrigger__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(gsap_dist_ScrollTrigger__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_form__WEBPACK_IMPORTED_MODULE_3__, _Schedule__WEBPACK_IMPORTED_MODULE_4__]);
([_form__WEBPACK_IMPORTED_MODULE_3__, _Schedule__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







if (false) {}
const Appointment = ()=>{
    const formRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const scheduleRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // Form animation
        gsap__WEBPACK_IMPORTED_MODULE_5___default().fromTo(formRef.current, {
            opacity: 0,
            x: -100
        }, {
            opacity: 1,
            x: 0,
            duration: 1.2,
            ease: "power3.out",
            scrollTrigger: {
                trigger: formRef.current,
                start: "top 80%",
                toggleActions: "play none none reverse"
            }
        });
        // Schedule animation
        gsap__WEBPACK_IMPORTED_MODULE_5___default().fromTo(scheduleRef.current, {
            opacity: .9,
            x: 100
        }, {
            opacity: 1,
            x: 0,
            duration: 1.2,
            ease: "power3.out",
            scrollTrigger: {
                trigger: scheduleRef.current,
                start: "top 80%",
                toggleActions: "play none none reverse",
                scrub: true
            }
        });
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        id: "appointment",
        className: "py-20 overflow-hidden bg-white",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_Container__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col lg:flex-row justify-between gap-4 items-center mt-5 p-6 border-8 border-gray-100",
                style: {
                    backgroundImage: "url(images/home/13.png)",
                    backgroundRepeat: "no-repeat",
                    backgroundSize: "cover",
                    backgroundPosition: "bottom"
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        ref: formRef,
                        className: "bg-[#fff6f4] p-8 w-full lg:w-[58%] border-8 border-white",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-3xl lg:text-4xl text-tertiary font-secondery py-6",
                                children: "Make Appointment"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-secondery mb-6",
                                children: "Submit your details & You will get a confirmation Mail."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_form__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        ref: scheduleRef,
                        className: "w-full lg:w-[48%] ",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Schedule__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Appointment);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9753:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ LoadingButton),
/* harmony export */   "q": () => (/* binding */ BookingButton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ui_icon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4068);
/* harmony import */ var antd_dist_antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4084);
/* harmony import */ var antd_dist_antd__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd_dist_antd__WEBPACK_IMPORTED_MODULE_3__);




const BookingButton = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
            className: "group hover:bg-white bg-primary transition-all py-2 mt-10 px-8 flex gap-2 justify-center items-center rounded-full",
            style: {
                boxShadow: "2px 2px 4px gray"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex justify-center items-center text-2xl group-hover:text-white text-primary transition-all w-8 h-8 md:w-10 md:h-10 group-hover:bg-primary bg-white rounded-full ml-[-20px]",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_icon__WEBPACK_IMPORTED_MODULE_2__.CalenderIcon, {})
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "text-md md:text-xl transition-all group-hover:text-primary text-white font-secondery",
                    children: "Make An Appointment"
                })
            ]
        })
    });
};
const LoadingButton = ()=>{
    const [position, setPosition] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("end");
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_dist_antd__WEBPACK_IMPORTED_MODULE_3__.Button, {
            loading: true,
            iconPosition: position,
            className: "bg-primary py-4 mt-10 px-20 flex gap-2 justify-center items-center rounded-full",
            style: {
                boxShadow: "2px 2px 4px gray"
            },
            children: "Loading..."
        })
    });
};



/***/ }),

/***/ 4356:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_Container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4482);
/* harmony import */ var _components_ui_icon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4068);
/* harmony import */ var _redux_api_Api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6627);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_redux_api_Api__WEBPACK_IMPORTED_MODULE_3__]);
_redux_api_Api__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const Schedule = ()=>{
    const { data  } = (0,_redux_api_Api__WEBPACK_IMPORTED_MODULE_3__/* .useBookingListQuery */ .rN)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_Container__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                            className: "flex gap-4 py-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "flex justify-center items-center bg-primary w-10 h-10 rounded-full text-2xl text-white ",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_icon__WEBPACK_IMPORTED_MODULE_2__.NotAvaileable, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-tertiary text-2xl md:text-4xl font-bold font-secondery pb-2",
                                    children: "Not available Dates:"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "ml-14",
                            children: data?.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center py-2 gap-4 text-xl md:text-[24px] ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                            className: "",
                                            children: item.date
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                            children: item.time
                                        })
                                    ]
                                }, item.id))
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                            className: "flex gap-4 mt-4",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "flex justify-center items-center bg-primary w-10 h-10 rounded-full text-2xl text-white ",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_icon__WEBPACK_IMPORTED_MODULE_2__.ClockIcon, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-tertiary text-2xl md:text-4xl font-bold font-secondery pb-2",
                                    children: "Opening hours:"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "ml-14",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-gray-800 text-[18px] md:text-[26px] py-2",
                                    children: "Mon to Sun: 9:00 am — 8:00 pm"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-800 text-[18px] md:text-[26px]",
                                    children: "Any Holiday: 9:00 am — 8:00 pm"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "py-4",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                            className: "flex gap-4",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "flex justify-center items-center bg-primary w-10 h-10 rounded-full text-2xl text-white ",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_icon__WEBPACK_IMPORTED_MODULE_2__.LocationIcon, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-tertiary text-2xl md:text-4xl font-bold font-secondery pb-2",
                                    children: "Location:"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "text-gray-600 text-[20px] md:text-2xl py-1 font-bold ml-14",
                            children: "5 Massey Square, East York, ON M4C 5L6, canada"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Schedule);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4464:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd_dist_antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4084);
/* harmony import */ var antd_dist_antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_dist_antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ui_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2400);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _redux_api_Api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6627);
/* harmony import */ var _BookingButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9753);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_redux_api_Api__WEBPACK_IMPORTED_MODULE_5__, react_toastify__WEBPACK_IMPORTED_MODULE_7__]);
([_redux_api_Api__WEBPACK_IMPORTED_MODULE_5__, react_toastify__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const Form = ()=>{
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [email, setEmail] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [phone, setPhone] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [subject, setSubject] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [date, setDate] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [time, setTime] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [description, setDescription] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [price, setPrice] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [selectedCategoryPrices, setSelectedCategoryPrices] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const formRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const { data: categories  } = (0,_redux_api_Api__WEBPACK_IMPORTED_MODULE_5__/* .useFindAllCategoriesQuery */ .hj)();
    const { data: prices  } = (0,_redux_api_Api__WEBPACK_IMPORTED_MODULE_5__/* .useFindAllPriceQuery */ .IZ)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (subject) {
            const categoryPrices = prices?.filter((price)=>price.CategoryId === Number(subject));
            setSelectedCategoryPrices(categoryPrices || []);
            setPrice("");
        }
    }, [
        subject,
        prices
    ]);
    const dateColllect = (_, dateString)=>{
        setDate(dateString);
    };
    const [booking, { isLoading  }] = (0,_redux_api_Api__WEBPACK_IMPORTED_MODULE_5__/* .useCreateBookingMutation */ .i9)();
    const handleAppoinment = async (e)=>{
        e.preventDefault();
        const selectedPrice = prices?.find((p)=>p.id === Number(price));
        const priceTitle = selectedPrice ? selectedPrice.title : "";
        try {
            await booking({
                name,
                email,
                phone,
                price: priceTitle,
                date,
                time,
                description
            }).unwrap();
            formRef.current.reset();
            react_toastify__WEBPACK_IMPORTED_MODULE_7__.toast.success("You will receive a confirmation Email!", {
                position: "bottom-right",
                autoClose: 8000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: false,
                draggable: false,
                progress: undefined,
                theme: "light"
            });
        } catch (err) {
            console.error("Booking failed", err);
            if (err.originalStatus === 406) {
                react_toastify__WEBPACK_IMPORTED_MODULE_7__.toast.error("This Date & Time is not available", {
                    position: "bottom-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: false,
                    draggable: false,
                    progress: undefined,
                    theme: "light"
                });
            } else {
                react_toastify__WEBPACK_IMPORTED_MODULE_7__.toast.error("Something went wrong! Please try again!", {
                    position: "bottom-left",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: false,
                    draggable: false,
                    progress: undefined,
                    theme: "light"
                });
            }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
        ref: formRef,
        onSubmit: handleAppoinment,
        className: "",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col gap-4 md:flex-row justify-between items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full py-2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "text",
                            placeholder: "Name",
                            className: "py-4 px-5 w-full border-b border-primary",
                            onChange: (e)=>setName(e.target.value),
                            required: true
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full py-2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "text",
                            placeholder: "Phone Number",
                            className: "py-4 px-5 w-full border-b border-primary",
                            onChange: (e)=>setPhone(e.target.value),
                            required: true
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-col gap-4 md:flex-row justify-between items-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full py-2",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        type: "email",
                        placeholder: "E-mail",
                        className: "py-4 px-5 w-full border-b border-primary",
                        onChange: (e)=>setEmail(e.target.value),
                        required: true
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "grid grid-cols-1 md:grid-cols-2 gap-4 md:flex-row justify-between items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: " py-2",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                            className: "py-4 px-5 w-full border-b border-primary text-secondery outline-none",
                            onChange: (e)=>setSubject(e.target.value),
                            required: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                    value: "",
                                    children: "Select Category"
                                }),
                                categories?.map((category)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                        value: category.id,
                                        children: category.title
                                    }, category.id))
                            ]
                        })
                    }),
                    subject && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "py-2",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                            className: "py-4 px-5 w-full border-b border-primary text-secondery outline-none",
                            onChange: (e)=>setPrice(e.target.value),
                            required: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                    value: "",
                                    children: "Select Service"
                                }),
                                selectedCategoryPrices.map((priceOption)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                        value: priceOption.id,
                                        children: [
                                            priceOption.title,
                                            " - $",
                                            priceOption.price
                                        ]
                                    }, priceOption.id))
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col gap-4 md:flex-row justify-between items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full py-2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_dist_antd__WEBPACK_IMPORTED_MODULE_2__.DatePicker, {
                            format: "YYYY-MM-DD",
                            disabledDate: (current)=>moment__WEBPACK_IMPORTED_MODULE_4___default()().add(-1, "days") >= current,
                            className: "py-4 px-5 w-full border-b border-primary outline-none",
                            onChange: dateColllect,
                            required: true
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full py-2",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                            className: "py-4 px-5 w-full border-b border-primary text-secondery outline-none",
                            onChange: (e)=>setTime(e.target.value),
                            required: true,
                            placeholder: "Select Time",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                    value: "",
                                    children: "Select Time"
                                }),
                                _components_ui_data__WEBPACK_IMPORTED_MODULE_3__/* .BookingTime */ .lI?.map((time)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                            value: time,
                                            children: time
                                        }, time)
                                    }))
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "py-2",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                    className: "py-4 px-5 w-full border-b border-primary text-secondery outline-none",
                    rows: "4",
                    cols: "50",
                    onChange: (e)=>setDescription(e.target.value),
                    required: true,
                    placeholder: "Please provide details about the service you're looking for..."
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_BookingButton__WEBPACK_IMPORTED_MODULE_6__/* .LoadingButton */ .f, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_BookingButton__WEBPACK_IMPORTED_MODULE_6__/* .BookingButton */ .q, {})
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Form);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;