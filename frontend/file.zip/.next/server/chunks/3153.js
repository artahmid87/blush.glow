"use strict";
exports.id = 3153;
exports.ids = [3153];
exports.modules = {

/***/ 3153:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _redux_api_Api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6627);
/* harmony import */ var antd_dist_antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4084);
/* harmony import */ var antd_dist_antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_dist_antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_redux_api_Api__WEBPACK_IMPORTED_MODULE_1__]);
_redux_api_Api__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const { Column  } = antd_dist_antd__WEBPACK_IMPORTED_MODULE_2__.Table;
const AppointmentList = ()=>{
    const { data , isLoading , isError , refetch  } = (0,_redux_api_Api__WEBPACK_IMPORTED_MODULE_1__/* .useBookingListQuery */ .rN)();
    const [deleteBooking] = (0,_redux_api_Api__WEBPACK_IMPORTED_MODULE_1__/* .useDeleteBookingMutation */ .XM)();
    const [isTabletOrMobile, setIsTabletOrMobile] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        const interval = setInterval(()=>{
            refetch();
        }, 1000);
        return ()=>clearInterval(interval);
    }, [
        refetch
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        const handleResize = ()=>{
            setIsTabletOrMobile(window.innerWidth < 1024);
        };
        window.addEventListener("resize", handleResize);
        handleResize();
        return ()=>window.removeEventListener("resize", handleResize);
    }, []);
    const handleDelete = async (id)=>{
        try {
            await deleteBooking(id).unwrap();
            refetch();
        } catch (error) {
            console.log(error);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "p-4",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-16 bg-pink-500 py-4 mb-4",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                    className: "text-2xl font-bold text-center text-white",
                    children: [
                        data?.length,
                        " Clients Available"
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: isTabletOrMobile ? "overflow-x-auto" : "",
                children: isTabletOrMobile ? // Mobile view as cards
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "grid gap-4",
                    children: data?.map((record)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "bg-gray-100 p-4 rounded-lg shadow-md",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "text-lg font-bold mb-2",
                                    children: record.name
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            children: "Email:"
                                        }),
                                        " ",
                                        record.email
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            children: "Phone:"
                                        }),
                                        " ",
                                        record.phone
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            children: "Date:"
                                        }),
                                        " ",
                                        record.date
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            children: "Time:"
                                        }),
                                        " ",
                                        record.time
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            children: "price:"
                                        }),
                                        " ",
                                        record.price
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            children: "Description:"
                                        }),
                                        " ",
                                        record.description
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex justify-between mt-4",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_dist_antd__WEBPACK_IMPORTED_MODULE_2__.Popconfirm, {
                                            title: "Delete the Booking",
                                            description: "Are you sure to delete this Booking?",
                                            onConfirm: ()=>handleDelete(record.id),
                                            okText: "Yes",
                                            cancelText: "No",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_dist_antd__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                                className: "px-4 py-1 bg-rose-500 rounded-3xl text-white hover:bg-white hover:text-red-500 transition-all",
                                                children: "Delete"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            href: {
                                                pathname: "/dashboard/confirmationBooking/[id]",
                                                query: {
                                                    id: record.id
                                                }
                                            },
                                            as: `/dashboard/confirmationBooking/${record.id}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_dist_antd__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                                className: "px-4 py-1 bg-yellow-400 rounded-3xl text-white hover:bg-white hover:text-yellow-400 transition-all",
                                                children: "Confirm"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }, record.id))
                }) : // Desktop view as a table
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd_dist_antd__WEBPACK_IMPORTED_MODULE_2__.Table, {
                    dataSource: data,
                    pagination: {
                        pageSize: 5
                    },
                    className: "w-full",
                    scroll: {
                        x: isTabletOrMobile ? "100%" : undefined
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Column, {
                            title: "Name",
                            dataIndex: "name"
                        }, "name"),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Column, {
                            title: "Email",
                            dataIndex: "email"
                        }, "email"),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Column, {
                            title: "Phone",
                            dataIndex: "phone"
                        }, "phone"),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Column, {
                            title: "Date",
                            dataIndex: "date"
                        }, "date"),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Column, {
                            title: "Time",
                            dataIndex: "time"
                        }, "time"),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Column, {
                            title: "Services",
                            dataIndex: "price"
                        }, "price"),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Column, {
                            title: "Description",
                            dataIndex: "description"
                        }, "description"),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Column, {
                            title: "Action",
                            render: (_, record)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd_dist_antd__WEBPACK_IMPORTED_MODULE_2__.Space, {
                                    size: "middle",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_dist_antd__WEBPACK_IMPORTED_MODULE_2__.Popconfirm, {
                                            title: "Delete the Booking",
                                            description: "Are you sure to delete this Booking?",
                                            onConfirm: ()=>handleDelete(record.id),
                                            okText: "Yes",
                                            cancelText: "No",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_dist_antd__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                                className: "px-4 py-1 bg-rose-500 rounded-3xl text-white hover:bg-white hover:text-red-500 transition-all",
                                                children: "Delete"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            href: {
                                                pathname: "/dashboard/confirmationBooking/[id]",
                                                query: {
                                                    id: record.id
                                                }
                                            },
                                            as: `/dashboard/confirmationBooking/${record.id}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_dist_antd__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                                className: "px-4 py-1 bg-yellow-400 rounded-3xl text-white hover:bg-white hover:text-yellow-400 transition-all",
                                                children: "Confirm"
                                            })
                                        })
                                    ]
                                })
                        }, "action")
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppointmentList);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;