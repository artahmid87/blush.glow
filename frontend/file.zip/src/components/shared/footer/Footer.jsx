import React from 'react';

import MainFooter from './mainFooter';


const Footer = () => {


  return (
    <div className = "overflow-hidden">

      <div >
        <MainFooter />
      </div>
    </div>
  );
};

export default Footer;
