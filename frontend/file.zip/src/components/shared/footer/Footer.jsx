import React from 'react';

import MainFooter from './mainFooter';


const Footer = () => {


  return (
    <div className = "">

      <div >
        <MainFooter />
      </div>
    </div>
  );
};

export default Footer;
