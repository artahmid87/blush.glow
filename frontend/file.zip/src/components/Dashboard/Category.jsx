import React from 'react'
import CrudCategory from './AddCategory'
import DisplayCategory from './displayCategory'

 const Category = () => {
  return (
    <div>
      <CrudCategory/>
      <DisplayCategory/>
    </div>
  )
}
export default Category