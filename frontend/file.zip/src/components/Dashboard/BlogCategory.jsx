import React from 'react'
import AddBlogCatgory from './addBlogCategory'
import DisplayBlogCategory from './DisplayBlogCategory'

 const BlogCategor = () => {
  return (
    <div>
      <AddBlogCatgory/>
      <DisplayBlogCategory/>
    </div>
  )
}
export default BlogCategor